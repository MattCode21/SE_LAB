package com.alumni.repository;

import com.alumni.model.LeaderboardModel;
import java.util.Arrays;
import java.util.List;

public class LeaderboardRepository {
    public List<LeaderboardModel> getLeaderboardData() {
        return Arrays.asList(
            new LeaderboardModel("Rahul Kumar", 150),
            new LeaderboardModel("Priya Sharma", 140),
            new LeaderboardModel("Amit Verma", 130),
            new LeaderboardModel("Sneha Gupta", 120),
            new LeaderboardModel("Rajesh Singh", 110)
        );
    }
}
