package com.alumni.repository;

import com.alumni.model.ProfileModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfileRepository extends JpaRepository<ProfileModel, Long> {
    // Additional query methods if needed
}
