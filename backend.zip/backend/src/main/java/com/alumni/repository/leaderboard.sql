CREATE TABLE leaderboard (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    points INT NOT NULL
);

-- Insert sample data
INSERT INTO leaderboard (name, points) VALUES
('Rahul Kumar', 150),
('Priya Sharma', 140),
('Amit Verma', 130),
('Sneha Gupta', 120),
('Rajesh Singh', 110);
