package com.alumni.service;

import com.alumni.model.Alumni;
import com.alumni.repository.AlumniRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AlumniService {

    @Autowired
    private AlumniRepository alumniRepository;

    // Get all alumni profiles
    public List<Alumni> getAllAlumni() {
        return alumniRepository.findAll();
    }

    // Add a new alumni profile
    public Alumni saveAlumni(Alumni alumni) {
        return alumniRepository.save(alumni);
    }
}
