package com.alumni.service;

import com.alumni.model.Blogs;
import com.alumni.repository.BlogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BlogService {

    @Autowired
    private BlogRepository blogRepository;

    public List<Blogs> getAllBlogs() {
        return blogRepository.findAll();
    }
}
