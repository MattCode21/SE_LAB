package com.alumni.service;

import com.alumni.model.LeaderboardModel;
import com.alumni.repository.LeaderboardRepository;
import java.util.List;

public class LeaderboardService {
    private final LeaderboardRepository repository;

    public LeaderboardService() {
        this.repository = new LeaderboardRepository();
    }

    public List<LeaderboardModel> getLeaderboard() {
        return repository.getLeaderboardData();
    }
}
