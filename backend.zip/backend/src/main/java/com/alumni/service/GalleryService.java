package com.alumni.service;

import com.alumni.model.Gallery;
import com.alumni.repository.GalleryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GalleryService {

    @Autowired
    private GalleryRepository galleryRepository;

    public List<Gallery> getAllGalleryItems() {
        return galleryRepository.findAll();
    }
}
