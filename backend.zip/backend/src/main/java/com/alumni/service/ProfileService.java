package com.alumni.service;

import com.alumni.model.ProfileModel;
import com.alumni.repository.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProfileService {

    @Autowired
    private ProfileRepository profileRepository;

    public ProfileModel getProfile(Long id) {
        return profileRepository.findById(id).orElse(null);
    }

    public ProfileModel updateProfile(ProfileModel profile) {
        return profileRepository.save(profile);
    }
}
