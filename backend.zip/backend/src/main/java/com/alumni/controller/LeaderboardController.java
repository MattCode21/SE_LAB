package com.alumni.controller;

import com.alumni.model.LeaderboardModel;
import com.alumni.service.LeaderboardService;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/leaderboard")
public class LeaderboardController {
    private final LeaderboardService service;

    public LeaderboardController() {
        this.service = new LeaderboardService();
    }

    @GetMapping
    public List<LeaderboardModel> getLeaderboard() {
        return service.getLeaderboard();
    }
}
