package com.alumni.controller;

import com.alumni.model.User;
import com.alumni.repository.UserRepository;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000") // Allow frontend requests
@RequestMapping("/oauth")
public class OAuthController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/google")
    public String googleAuth(@RequestBody Map<String, String> requestBody) {
        String token = requestBody.get("token");

        // Validate token with Google's API (optional)
        // Decode token and extract user info (email, name, etc.)
        String email = extractEmailFromToken(token); // Implement this method

        // Check if user exists in registered alumni database
        User user = userRepository.findByEmail(email);
        if (user == null) {
            return "User not registered as alumni.";
        }

        // Save user info if not already saved
        if (!userRepository.existsByEmail(email)) {
            User newUser = new User();
            newUser.setEmail(email);
            newUser.setName(extractNameFromToken(token)); // Implement this method
            userRepository.save(newUser);
        }

        return "Authentication successful!";
    }

    private String extractEmailFromToken(String token) {
        // Decode JWT token and extract email (implement logic here)
        return "example@example.com"; // Replace with actual implementation
    }

    private String extractNameFromToken(String token) {
        // Decode JWT token and extract name (implement logic here)
        return "Example Name"; // Replace with actual implementation
    }
}
