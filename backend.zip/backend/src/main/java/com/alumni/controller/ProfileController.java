package com.alumni.controller;

import com.alumni.model.ProfileModel;
import com.alumni.service.ProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {

    @Autowired
    private ProfileService profileService;

    @GetMapping("/{id}")
    public ProfileModel getProfile(@PathVariable Long id) {
        return profileService.getProfile(id);
    }

    @PutMapping("/{id}")
    public ProfileModel updateProfile(@PathVariable Long id, @RequestBody ProfileModel profile) {
        profile.setId(id);
        return profileService.updateProfile(profile);
    }
}
