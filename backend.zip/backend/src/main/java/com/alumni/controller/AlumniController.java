package com.alumni.controller;

import com.alumni.model.Alumni;
import com.alumni.service.AlumniService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/alumni")
@CrossOrigin(origins = "http://localhost:3000") // Allow React frontend to access this API
public class AlumniController {

    @Autowired
    private AlumniService alumniService;

    // Get all alumni profiles
    @GetMapping
    public List<Alumni> getAllAlumni() {
        return alumniService.getAllAlumni();
    }

    // Add a new alumni profile
    @PostMapping
    public Alumni addAlumni(@RequestBody Alumni alumni) {
        return alumniService.saveAlumni(alumni);
    }
}
