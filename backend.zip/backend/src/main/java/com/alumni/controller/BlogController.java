package com.alumni.controller;

import com.alumni.model.Blogs;
import com.alumni.service.BlogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/blogs")
@CrossOrigin(origins = "http://localhost:3000")
public class BlogController {

    @Autowired
    private BlogService blogService;

    @GetMapping
    public List<Blogs> getAllBlogs() {
        return blogService.getAllBlogs();
    }
}