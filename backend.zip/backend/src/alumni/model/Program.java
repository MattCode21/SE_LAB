package com.alumni.model;

public enum Program {
    BTech, MTech, PhD, MBA
}
