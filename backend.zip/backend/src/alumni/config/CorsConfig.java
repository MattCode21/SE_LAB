package com.alumni.config;

public class CorsConfig {
    
}
