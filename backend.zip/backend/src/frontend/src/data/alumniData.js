
// Sample alumni data
export const alumniProfiles = [
  {
    id: 1,
    name: "Rahul Sharma",
    batch: "2018",
    department: "CSE",
    company: "Google",
    designation: "Senior Software Engineer",
    location: "Bangalore, India"
  },
  {
    id: 2,
    name: "Priya Patel",
    batch: "2015",
    department: "ECE",
    company: "Amazon",
    designation: "Technical Program Manager",
    location: "Seattle, USA"
  },
  {
    id: 3,
    name: "Amit Kumar",
    batch: "2010",
    department: "Mechanical",
    company: "Tata Motors",
    designation: "Product Development Lead",
    location: "Pune, India"
  },
  {
    id: 4,
    name: "Deepa Nair",
    batch: "2019",
    department: "EEE",
    company: "Shell",
    designation: "Energy Systems Engineer",
    location: "Mumbai, India"
  },
  {
    id: 5,
    name: "Sanjay Menon",
    batch: "2012",
    department: "Civil",
    company: "L&T",
    designation: "Project Manager",
    location: "Dubai, UAE"
  },
  {
    id: 6,
    name: "Ananya Reddy",
    batch: "2016",
    department: "CSE",
    company: "Microsoft",
    designation: "Product Manager",
    location: "Hyderabad, India"
  }
];
